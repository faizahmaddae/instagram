import 'package:flutter/material.dart';

class AddPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return new _AddPageState();
  }

}

class _AddPageState extends State<AddPage>{
  @override
  Widget build(BuildContext context) {
    return new Container(
      color: Colors.yellow,
    );
  }

}