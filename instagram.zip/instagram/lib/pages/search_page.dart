import 'package:flutter/material.dart';

class SearchPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return new _SearchPageState();
  }

}

class _SearchPageState extends State<SearchPage>{
  @override
  Widget build(BuildContext context) {
    return new Container(
      color: Colors.blue,
    );
  }

}