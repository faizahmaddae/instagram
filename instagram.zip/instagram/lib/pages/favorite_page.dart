import 'package:flutter/material.dart';

class FavoritePage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return new _FavoritePageState();
  }

}

class _FavoritePageState extends State<FavoritePage>{
  @override
  Widget build(BuildContext context) {
    return new Container(
      color: Colors.pink,
    );
  }

}